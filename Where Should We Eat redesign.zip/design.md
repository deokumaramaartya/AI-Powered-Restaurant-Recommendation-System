# Where should we eat? — Design spec (Monsoon Street, dark)

AI-powered Bangalore restaurant recommender. Visual redesign only: no API, feature, or copy-meaning changes.
Source of truth: `Where Should We Eat.dc.html` · Standalone: `Where Should We Eat (standalone).html`

## 1. Direction
Bangalore on a rainy night: wet slate streets lit by warm sodium lamps. The interface is cool and quiet, and the warm amber accent marks the decisions (the CTA, ratings, rank, "Why it fits").
Not neon, not purple SaaS, not acid-green AI, not flat #000 with grey cards.
- Dark only: `color-scheme: dark`, no light toggle.
- Depth comes from a lamp glow at the top left, a cool rain-blue haze at the top right, faint diagonal rain streaks and a soft vignette. Never a flat fill.

## 2. Palette
| Token | Hex | Use |
|---|---|---|
| `--bg` (Wet tarmac) | `#11171B` | Page |
| `--surface` (Slate) | `#1A2228` | Panels, cards |
| `--surface-raised` | `#243039` | Form panel, summary chit |
| `--text` (Mist) | `#EAEFF1` | Primary text |
| `--muted` (Drizzle) | `#98A7B0` | Secondary text |
| `--accent` (Sodium lamp) | `#F5B84E` | CTA, rating, rank, focus |
| `--danger` (Byadgi chilli) | `#F07A6A` | Errors, validation |

Supporting: `--ember #E0814F` (only the "Ranked without AI" notice), `--leaf #7FC2AC` (available services), `--line #2F3C45`, `--line-strong #4E5F6A` (perforation), `--faint #73838C` (placeholders, ticks), `--accent-ink #17120A` (text on the accent).

Contrast: muted on bg is about 7:1 and accent on bg about 10:1. Text on the accent always uses `--accent-ink`.

## 3. Typography
- **Display:** Young Serif 400, used for the title, section headings and restaurant names.
- **Body:** Figtree 400–700, used for the form, explanations and metadata. Numbers use `font-variant-numeric: tabular-nums`.

| Role | Size / line height |
|---|---|
| Hero | clamp(46px → 84px) / 0.98 |
| H2 | 28–36px / 1.1 |
| Card name | 22–27px / 1.15 |
| Lede | 19px / 1.5 |
| Body | 16px / 1.55 |
| Small | 14px |
| Label | 12px caps, tracking .14em |

## 4. Layout
```
max 1200px
BANGALORE · TONIGHT
Where should we eat?          ← hero-level brand, not nav text
One-line lede
┌ Preferences 348px sticky ┐  ┌ Results (fluid) ─────────────┐
│ Locality *               │  │ Your shortlist · <locality>  │
│ Budget ▭▭▭▭              │  │ [AI chit | Fallback notice]  │
│ Cuisines chips/search/↕  │  │ [Widened search note]        │
│ Rating ──●──             │  │ ┌01┆ card ┐ ┌02┆ ┐ ┌03┆ ┐    │
│ Anything else? 0/300     │  └──────────────────────────────┘
│ Results 3/5/10           │
│ [ Find restaurants ]     │
└──────────────────────────┘
```
- ≤820px: one column. The CTA is pinned to the bottom of the form viewport. After submit, scroll to the results (`scroll-margin-top` clears the condensed bar). The condensed preference bar shows the locality, a filter summary and **Edit**.
- The hero is never a card. The first viewport holds only the brand, the lede and the form entry.

## 5. Signature motif: the KOT chit
The torn kitchen order ticket used at darshinis and biryani counters. Use it **only in results**:
- **Card rank stub:** an 84px column (56px on mobile) with a dotted perforation on its right edge and two punched notches (circles in the bg colour) at top and bottom.
- **AI summary:** a "TONIGHT'S READ" header above a dotted tear line.

## 6. Motion (three moments only)
1. Masthead settles in: 900ms, `cubic-bezier(.2,.7,.2,1)`, 6px rise.
2. CTA press: `scale(.98)` over 120ms.
3. Result reveal: each card rises 12px over 450ms, staggered 70ms.

Skeleton shimmer runs at 1.3s and exists only as loading feedback.
`prefers-reduced-motion: reduce` turns off all animation and transitions.

## 7. Components
**Segmented budget:** four equal cells in an inset track. The selected cell is solid accent with ink text. The range hint sits under each label in 11px: all / ≤₹500 / ₹500–1k / ₹1k+. Use `aria-pressed` or a radio group, min-height 52px. Results 3/5/10 uses the same pattern.

**Cuisine chips and list:** chips sit above the search so selections stay visible.
- Chip: 14% accent fill, 45% accent border, `white-space: nowrap`, `aria-label="Remove {cuisine}"`.
- List: native checkboxes with `accent-color` set to the accent; rows 40px tall (44px on mobile); max-height 172px with its own scroll (`overflow-x: hidden`, thin dark scrollbar). The label reads "any match".

**Rating slider:** native range input, 0–5, step 0.5. The live value is an `<output>` (18px bold accent) showing "Any" at 0, otherwise "4.0+". Tick labels 0 · 2.5 · 5.

**Summary and fallback banners:**
- AI: raised surface and the chit header, with an 18px body.
- Fallback: an ember notice in the same slot (10% fill, 55% border, `role="status"`), titled "Ranked without AI". Because it uses the same slot, the layout never jumps.
- Widened search: a neutral note below either banner that names exactly what was loosened.

**Restaurant card:** built from `<ol>`/`<li>` so the rank is semantic. Reading order:
1. Name and rating /5 with votes
2. Cuisines
3. Cost for two, type, Online order / Table booking (available in leaf; unavailable struck through and muted)
4. **Why it fits**: an accent-tinted block, 16px, the brightest text on the card
5. Address, muted

**Loading skeleton:** mirrors the real layout, with a header bar, a banner block and N cards (stub plus three bars). The region gets `aria-busy`. The CTA reads "Finding restaurants…" and is disabled.

**Idle:** a dashed chit outline with "Your shortlist shows up here" and one line of guidance.

**Empty and error states:**
- Meta load failure: inline in the Locality field with a Retry button.
- Validation: an inline `role="alert"` message under Locality: "Pick a locality to start — everything else is optional."
- Search failure: shown in danger colour with a **Try again** button.
- No match even after relaxation: neutral, lists what was relaxed and three suggestions, with **Edit preferences**.
- Empty dataset: neutral; the copy tells the user to run the ingest step, then reload.

## 8. Accessibility
- Every control has a `<label>` or `<legend>`, and required fields are marked.
- Focus ring: `outline: 2px solid var(--accent); outline-offset: 2px` on `:focus-visible`.
- A polite live region announces results, e.g. "3 restaurants found in Koramangala 5th Block". Fallback, empty and error states are announced too.
- Tap targets are at least 44px on mobile.
- Reduced motion is respected throughout.

## 9. `:root` tokens
```css
:root {
  color-scheme: dark;
  --bg: #11171B;
  --surface: #1A2228;
  --surface-raised: #243039;
  --surface-sunken: #131A1F;
  --line: #2F3C45;
  --line-strong: #4E5F6A;
  --text: #EAEFF1;
  --text-soft: #C7D1D6;
  --muted: #98A7B0;
  --faint: #73838C;
  --accent: #F5B84E;
  --accent-hi: #F8C468;
  --accent-lo: #E9A632;
  --accent-ink: #17120A;
  --accent-tint: rgba(245, 184, 78, 0.08);
  --accent-edge: rgba(245, 184, 78, 0.22);
  --ember: #E0814F;
  --leaf: #7FC2AC;
  --danger: #F07A6A;

  --page-bg:
    radial-gradient(1100px 560px at 8% -8%, rgba(245,184,78,.17), transparent 62%),
    radial-gradient(800px 480px at 105% 0%, rgba(110,150,175,.12), transparent 60%),
    repeating-linear-gradient(104deg, rgba(234,239,241,.022) 0 1px, transparent 1px 11px),
    radial-gradient(ellipse 120% 90% at 50% 40%, transparent 55%, rgba(0,0,0,.5) 100%),
    var(--bg);
  --card-bg: linear-gradient(180deg, #1C252C, #161E23);
  --panel-bg: linear-gradient(180deg, rgba(36,48,57,.92), rgba(26,34,40,.92));
  --cta-bg: linear-gradient(180deg, var(--accent-hi), var(--accent-lo));

  --font-display: 'Young Serif', Georgia, serif;
  --font-body: 'Figtree', 'Segoe UI', sans-serif;
  --fs-hero: clamp(2.875rem, 6vw + 1rem, 5.25rem);
  --fs-h2: clamp(1.75rem, 2vw + 1rem, 2.25rem);
  --fs-card: clamp(1.375rem, 1vw + 1rem, 1.6875rem);
  --fs-lede: 1.1875rem;
  --fs-body: 1rem;
  --fs-small: 0.875rem;
  --fs-label: 0.75rem;
  --lh-tight: 1.05;
  --lh-body: 1.55;

  --r-sm: 8px; --r-md: 10px; --r-lg: 14px; --r-xl: 18px; --r-pill: 999px;
  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px;
  --space-5: 24px; --space-6: 40px; --space-7: 56px;
  --panel-w: 348px;
  --content-max: 1200px;
  --tap: 44px;
  --shadow-panel: 0 24px 60px rgba(0,0,0,.35);

  --ease-out: cubic-bezier(.2, .7, .2, 1);
  --dur-settle: 900ms;
  --dur-rise: 450ms;
  --stagger: 70ms;
}
```
Fonts: `https://fonts.googleapis.com/css2?family=Young+Serif&family=Figtree:wght@400;500;600;700&display=swap`

## 10. Don'ts
- No stats strips, promo chips or floating badges on the hero.
- Use the chit motif only in results.
- Use ember only for the fallback notice.
- Don't add features, maps, photo galleries or a light mode.
